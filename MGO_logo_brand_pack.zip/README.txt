MGO Brand concept 01

Assets:
- mgo-logo-horizontal.svg/png: primary transparent logo for dark backgrounds
- mgo-logo-light.svg/png: primary transparent logo for light backgrounds
- mgo-app-icon.svg/png: application icon (1024px)
- mgo-icon-64,180,192,256,512.png: small-size exports
- mgo-brand-preview.png: design presentation

Device interpretations: Nokia N-Gage QD, Nokia N95, Sony Ericsson K750i.
N-Gage QD outer silhouette follows grayhex/MGO/design/phones/nokia-n-gage-qd/silhouette.svg.
Text uses Inter (system fallback font in SVG).

Concept files prepared for design iteration; not pushed to GitHub.
